# -----------------------------------------------------------------------------
#
#  FreeType high-level python API - copyright 2011 Nicolas P. Rougier
#  Distributed under the terms of the new BSD license.
#
# -----------------------------------------------------------------------------

Contributors:

* Titusz Pan (bug report)
* Ekkehard.Blanz (bug report)
